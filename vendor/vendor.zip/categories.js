const categories = [
        {
            slug: 'shop',
            name: 'Shop',
        },
        {
            slug: 'necklaces',
            name: 'Necklaces',
        },
        {
            slug: 'bracelets',
            name: 'Bracelets',
        },
        {
            slug: 'brooches',
            name: 'Brooches',
        },
        {
            slug: 'earrings',
            name: 'Earrings',
        },
        {
            slug: 'rings',
            name: 'Rings',
        },
        {
            slug: 'headware',
            name: 'Headwear',
        }
];

module.exports = categories;
